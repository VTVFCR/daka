from django.db import models
from django.utils import timezone


class Qingjia(models.Model):
    # 账号（直接使用字符串存储）
    aaccount = models.CharField(max_length=50, verbose_name="账号")
    # 请假日期
    leave_date = models.DateField(verbose_name="请假日期")
    # 请假原因
    reason = models.TextField(blank=True, verbose_name="请假原因")
    class Meta:
        db_table = "qingjia"  # 更改表名

    def __str__(self):
        return f"{self.account} - {self.leave_date}"


#打卡记录
class UserRecord(models.Model):
    account  = models.CharField(max_length=50, unique=False, verbose_name="账号")
    nickname = models.CharField(max_length=50, verbose_name="昵称")
    create_time = models.DateTimeField(default=timezone.now, verbose_name="当时时间")

    class Meta:
        db_table = "user_record"  # 对应数据库表名
        verbose_name = "用户记录"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.account
