from django.shortcuts import render
from web.models import Qingjia
def qingjia(request):
    return render(request,"web/qingjia.html")#跳转到请假页面
def doqingjia(request):
    try:
        ob = Qingjia()
        ob.aaccount = request.POST['username']
        ob.leave_date = request.POST['datetime']
        ob.reason = request.POST['yuanyin']
        ob.save()
        content = {"info":"请假成功"}
    except Exception as err:
        print(err)
        content = {"info":"请假失败"}
    return render(request,"web/info.html",content)


