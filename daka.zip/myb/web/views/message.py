from django.shortcuts import render
from myadmin.models import Message
def message(request):
    obm=Message.objects.filter(receiver_account="lisi")
    content={"obm":obm}
    return render(request,"web/message.html",content)
