from django.shortcuts import render
from myadmin.models import User
from web.models import UserRecord
def daka(request):
    return render(request,"web/daka.html")
def dodaka(request):
    if 'webuser' in request.session:
        # 从session中获取当前登录用户的username
        # 注意：根据之前的登录逻辑，webuser是字典，需要取'username'键
        current_username = request.session['webuser']['username']
        
        # 筛选出当前登录用户的信息
        # 使用first()获取单个用户对象（避免返回查询集）
        umod = User.objects.filter(username=current_username).first()
        
        if umod:  # 确保用户存在
            # 创建UserRecord对象
            mmod = UserRecord()
            # 将User中的数据同步到UserRecord
            mmod.account = umod.username  # 账号（直接使用用户名）
            
            # 昵称：假设User模型有nickname字段，若无可改用username或其他字段
            mmod.nickname = umod.nickname if hasattr(umod, 'nickname') else umod.username
            
            # create_time会自动填充，无需手动设置
            
            # 保存到数据库
            mmod.save()
            
            # 打卡成功，返回成功信息
            return render(request, 'web/info.html', {'info': '打卡成功'})
        else:
            # 用户不存在（理论上不会出现，因为session存在）
            return render(request, 'web/info.html', {'info': '用户不存在'})
   

