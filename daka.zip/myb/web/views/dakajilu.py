#打卡记录
from django.shortcuts import render
from web.models import UserRecord
from myadmin.models import User
def jilu(request):
    if 'webuser' in request.session:
         # 从session中获取当前登录用户的username
        # 注意：根据之前的登录逻辑，webuser是字典，需要取'username'键
        current_username = request.session['webuser']['username']
        
        # 筛选出当前登录用户的信息
        # 使用first()获取单个用户对象（避免返回查询集）
        umod = User.objects.filter(username=current_username).first()
        rmod = UserRecord.objects.filter(account= umod.username)
        content = {"rlist":rmod}


    return render(request,"web/dakajilu.html",content)