from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.urls import reverse
# Create your views here.
def index(request):
    return render(request,"web/index.html")
