from django.shortcuts import redirect, render
from django.urls import reverse
from myadmin.models import User
from datetime import datetime
#加载登入页面
def login(request):
    return render(request,"web/login.html")
#执行登录
def dologin(request):
    try:
        user = User.objects.get(username=request.POST['username'])
        if user.status==1:
            p = request.POST['password']
            if user.password_salt == p:
                print("登入成功")
                #登录记录
                request.session['webuser'] = user.toDict()
                return redirect(reverse("web_index"))
            else:
                content = {"info":"登录账号不存在"}
    except Exception as err:
        print(err)
        content = {"info":"登录账号不存在"}
    return render(request,'myadmin/info.html',content)
#进行退出操作
def logout(request):
    del request.session['adminuser']
    return redirect(reverse("web_login"))
#跳转到注册页面
def register(request):
    return render(request,"web/register.html")
#进行注册
def doregister(request):
    try:
        ob=User()
        ob.username=request.POST['username']
        ob.nickname=request.POST['nickname']
        ob.password_salt=request.POST['password']
        ob.status = 1
        ob.create_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ob.update_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ob.save()
        content={"info":"注册成功"}
    except Exception as err:
        print(err)
        content={"info":"注册失败"}
    return render(request,"myadmin/reinfo.html",content)
