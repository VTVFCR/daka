from django.urls import path,include
from web.views import index,login,qingjia,message,daka,dakajilu,main
urlpatterns = [
    #员工登录注册
    path("login/",login.login,name="web_login"),#跳转到登录页面
    path("dologin/",login.dologin,name="web_dologin"),#执行登录
    path("regiter/",login.register,name="web_register"),#跳转到注册页面
    path("doregister/",login.doregister,name="web_doregister"),#执行注册
    path("login/",login.logout,name="web_logout"),#执行退出
    #为url路由添加请求前卫web/，凡是代词前缀的url地址必须登录后才可以访问
    path("web/",include([
        path('index/',index.index,name='web_index'),#跳转到首页
        #请假功能
        path('qingjia/',qingjia.qingjia,name="web_qingjia"),#跳转到请假页面
        path('doqingjia/',qingjia.doqingjia,name="web_doqingjia"),#执行请假功能
        #信息显示
        path('message/',message.message,name="web_message"),
        #打卡操作
        path("daka/",daka.daka,name="web_daka"),#显示打卡页面、
        path("dodaka/",daka.dodaka,name="web_dodaka"),#进行打卡
        #打卡记录
        path("jilu/",dakajilu.jilu,name="web_jilu"),#显示打卡记录
        #显示主页
        path("main/",main.main,name="web_main")
    ]))
]