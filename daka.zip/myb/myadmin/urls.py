from django.urls import path
from myadmin.views import index
from myadmin.views import user
from myadmin.views import qingjia,dakajilu
urlpatterns = [
    path("",index.index,name="myadmin_index"),
    #员工信息
    path("user/<int:pIndex>",user.index,name="myadmin_user_index"),#浏览信息
    path("user/add",user.add,name="myadmin_user_add"),#显示添加表单
    path("user/insert",user.insert,name="myadmin_user_insert"),#执行添加
    path("user/del/<int:uid>",user.delete,name="myadmin_user_del"),#执行删除信息
    path('user/edit/<int:uid>', user.edit, name="myadmin_user_edit"),#准备信息编辑
    path('user/update/<int:uid>', user.update, name="myadmin_user_update"),#执行信息编辑
    #登录操作
    path("login",index.login,name="myadmin_login"),#实现登录页面
    path("dologin",index.dologin,name="myadmin_dologin"),#执行登录
    path("logout",index.logout,name="myadmin_logout"),#退出登录
    #注册操作
    path("register",index.register,name="myadmin_register"),#打开注册页面
    path("doregister",index.doregister,name="myadmin_doregister"),#执行注册
    #处理请假
    path("chuliq/",qingjia.chuliq,name="myadmin_chuliq"),#显示员工请假信息
    path("pizhun/<int:uid>/",qingjia.pizhun,name="myadmin_qingjia_pizhun"),#处理操作
    path("bupizhun/<int:uid>/",qingjia.bupizhun,name="myadmin_qingjia_bupizhun"),#处理操作
    #打卡记录
    path("daka/",dakajilu.jilu,name="myadmin_jilu"),
]