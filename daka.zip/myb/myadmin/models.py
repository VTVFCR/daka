from django.db import models
from datetime import datetime

#员工账号信息模型
class User(models.Model):
    username = models.CharField(max_length=50)    #员工账号
    nickname = models.CharField(max_length=50)    #昵称
    password_hash = models.CharField(max_length=100)#密码
    password_salt = models.CharField(max_length=50)    #密码干扰值
    status = models.IntegerField(default=1)    #状态:1正常/2禁用/9删除
    create_at = models.DateTimeField(default=datetime.now)    #创建时间
    update_at = models.DateTimeField(default=datetime.now)    #修改时间

    def toDict(self):
        return {'id':self.id,'username':self.username,'nickname':self.nickname,'password_hash':self.password_hash,'password_salt':self.password_salt,'status':self.status,'create_at':self.create_at.strftime('%Y-%m-%d %H:%M:%S'),'update_at':self.update_at.strftime('%Y-%m-%d %H:%M:%S')}

    class Meta:
        db_table = "user"  # 更改表名
        
#请假消息模型

class Message(models.Model):
    # 接收人账号（对应数据库 receiver_account，非空）
    receiver_account = models.CharField(max_length=50, verbose_name="接收人账号")
    # 消息内容（对应数据库 content，非空）
    content = models.TextField(verbose_name="消息内容")
    # 创建时间（自动填充当前时间，对应数据库 create_time）
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    # 消息状态（0=未读，1=已读，默认未读，对应数据库 status）
    status = models.SmallIntegerField(default=0, verbose_name="消息状态", choices=[(0, '未读'), (1, '已读')])

    class Meta:
        db_table = "message"  # 绑定数据库中的 message 表
        verbose_name = "系统消息"
        verbose_name_plural = "系统消息"
        ordering = ["-create_time"]  # 默认按创建时间倒序（最新消息在前）

    def __str__(self):
        # 显示“接收人+消息前15字”，方便识别
        return f"{self.receiver_account}：{self.content[:15]}..."