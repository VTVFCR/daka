from django.shortcuts import render
from web.models import Qingjia
from myadmin.models import Message
from datetime import datetime
def chuliq(request):
    ob = Qingjia.objects.all()
    content = {"qlist":ob}
    return render(request,"myadmin/chuliq.html",content)
def pizhun(request,uid=0):
    try:
        ob = Qingjia.objects.get(id=uid)
        ob.delete()
        #消息输送
        obm = Message()
        obm.receiver_account = ob.account
        obm.content = "申请成功"
        obm.save()
        context={"info":"处理成功"}
    except Exception as err:
        print(err)
        context={"info":"处理失败"}
    return render(request,"myadmin/info.html",context)
def bupizhun(request,uid=0):
    try:
        ob = Qingjia.objects.get(id=uid)
        ob.delete()
        #消息输送
        obm = Message()
        obm.receiver_account = ob.account
        obm.content = "不批准"
        obm.save()
        content={"info":"处理成功"}
    except Exception as err:
        print(err)
        content={"info":"处理失败"}
    return render(request,"myadmin/info.html",content)