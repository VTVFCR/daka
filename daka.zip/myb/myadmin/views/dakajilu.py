from django.shortcuts import render
from web.models import UserRecord
def jilu(request):
    ob = UserRecord.objects.all()
    content = {"rlist":ob}
    return render(request,"myadmin/dakajilu.html",content)