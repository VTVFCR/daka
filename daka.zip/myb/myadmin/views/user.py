from django.shortcuts import render
from django.http import HttpResponse
from django.core.paginator import Paginator
from django.db.models import Q   #搜索框里的或关系
from myadmin.models import User
from datetime import datetime
import hashlib
# Create your views here.
def index(request,pIndex=1):
    try:
        umod = User.objects
        ulist = umod.filter(status__lt=9)
        mywhere=[]
        #获取并判断搜索条件
        kw = request.GET.get("keyword",None)
        if kw:
            ulist = ulist.filter(Q(username__contains=kw) | Q(nickname__contains=kw))
            mywhere.append('keyword='+kw)

        #执行分页处理
        pIndex = int(pIndex)
        page = Paginator(ulist,5)#5条数据分页
        maxpages = page.num_pages#获取最大页数
        #判断当前页是否越界
        if pIndex > maxpages:
            pIndex = maxpages
        if pIndex < 1:
            pIndex = 1
        list2 = page.page(pIndex)#获取当前页数据
        plist = page.page_range#获取页码列表信息
        centext = {"userlist":list2,'plist':plist,'pIndex':pIndex,'maxpages':maxpages,'mywhere':mywhere}
        return render(request,"myadmin/user.html",centext)
    except:
        return HttpResponse("没有找到任何信息")
def add(request):
    return render(request,"myadmin/add.html")
def insert(request):
    try:
        ob = User()
        ob.username = request.POST['username']
        ob.nickname = request.POST['nickname']
        # 状态映射转换
        status_map = {
            '正常': 1,
            '禁止': 2,
            '管理员': 6,
            '删除': 9
        }
        # 获取并转换状态值，默认设为1（正常）
        ob.status = status_map.get(request.POST['status'].strip(), 1)
        ob.create_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ob.update_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 保留原始密码到password_salt（如果需要）
        ob.password_salt = request.POST['password']
        
        # 添加MD5加密功能，将结果存储到password_hash
        # 创建MD5对象并加密密码
        md5 = hashlib.md5()
        # 将密码转换为字节串并更新到MD5对象
        md5.update(request.POST['password'].encode('utf-8'))
        # 获取加密后的16进制字符串并赋值给password_hash
        ob.password_hash = md5.hexdigest()
        
        ob.save()
        context = {"info": "添加成功"}
    except Exception as err:
        print(err)
        context = {"info": "添加失败"}
    return render(request, "myadmin/info.html", context)
def delete(request,uid=0):
    try:
        ob = User.objects.get(id=uid)
        ob.status = 9
        ob.update_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ob.save()
        context={'info':'删除成功'}
    except Exception as err:
        print(err)
        context={'info':"删除失败"}
    return render(request, "myadmin/info.html", context)
def edit(request,uid=0):
    try:
        ob = User.objects.get(id=uid)

        context={'ob': ob}
        return render(request,"myadmin/edit.html",context)
    except Exception as err:
        print(err)
        context={'info':"没有找到要修改的信息"}
        return render(request, "myadmin/info.html", context)
def update(request, uid):
    try:
        ob = User.objects.get(id=uid)
        ob.nickname = request.POST['nickname']
        
        # 新增：状态文本转数字（与insert视图逻辑一致）
        status_map = {
            '正常': 1,
            '禁止': 2,
            '管理员': 6
        }
        # 获取转换后的数字（默认设为1=正常，防止无效值）
        ob.status = status_map.get(request.POST['status'].strip(), 1)
        
        ob.update_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ob.save()  # 此时status是数字，可正常保存
        context={'info':'修改成功'}
    except Exception as err:
        print(err)  # 打印错误到终端，方便排查
        context={'info':"修改失败"}
    return render(request, "myadmin/info.html", context)