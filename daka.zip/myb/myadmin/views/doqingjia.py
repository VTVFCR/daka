from django.shortcuts import render
from web.models import Qingjia
def chuli(request):
    return render(request,"myadmin",)