import hashlib
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.urls import reverse
from myadmin.models import User
from datetime import datetime
# Create your views here.
def index(request):
    return render(request,"myadmin/index.html")
#会员登入表单
def login(request):
    return render(request,"myadmin/login.html")
#执行登录
def dologin(request):
    try:
        user=User.objects.get(username=request.POST['username'])
        print("前端提交的用户名：", request.POST.get('username'))  # 打印验证
        if user.status == 6:
            #判断密码是否相同
            p = request.POST['password']
            if user.password_salt == p:
                print('登入成功')
                #登录记录
                request.session['adminuser'] = user.toDict()
                #重定向到后台首页
                return redirect(reverse("myadmin_index"))
            else:
                context = {"info":"密码错误"}
    except Exception as err:
        print(err)
        context = {"info":"登录账号不存在"}
    return render(request,"myadmin/login.html",context)
#执行退出
def logout(request):
    del request.session['adminuser']
    return redirect(reverse("myadmin_login"))

#进行注册，
#打开注册页面
def register(request):
    return render(request,"myadmin/register.html")
def doregister(request):
    try:
        ob = User()
        ob.username = request.POST['username']
        ob.nickname = request.POST['nickname']
        ob.password_salt = request.POST['password']
        ob.status = 6
        ob.create_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ob.update_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ob.save()
        content = {"info":"注册成功"}
    except Exception as err:
        print(err)
        content = {"info":"注册失败"}
    return render(request,"myadmin/reinfo.html",content)